"""
=========================================================
Jazz Groove Analyzer (JGA)

Feature Extractor Interface

Copyright © 2026 Angelo Tracanna
=========================================================
"""

from __future__ import annotations

from abc import ABC, abstractmethod

from jga.observation.feature import Feature
from jga.observation.signal_representation import SignalRepresentation


class FeatureExtractor(ABC):
    """
    Interface for feature extraction algorithms.
    """

    @abstractmethod
    def extract(
        self,
        signal: SignalRepresentation,
    ) -> tuple[Feature, ...]:
        """
        Extract observable features from a signal representation.
        """
        raise NotImplementedError
