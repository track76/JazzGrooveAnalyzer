"""
=========================================================
Jazz Groove Analyzer (JGA)

File:
    analysis_context.py

Description:
    Shared analysis context used by all JGA
    engines during the analysis pipeline.

Author:
    Angelo Tracanna

Copyright © 2026 Angelo Tracanna
All Rights Reserved.
=========================================================
"""

from dataclasses import dataclass, field

import numpy as np

from jga.core.audio_file import AudioFile

from jga.runtime.analysis_log import AnalysisLog
from jga.runtime.analysis_report import AnalysisReport


@dataclass
class AnalysisContext:
    """
    Shared state used by all JGA engines
    during the analysis of a musical
    performance.
    """

    # =====================================================
    # Original Audio
    # =====================================================

    audio: AudioFile

    # =====================================================
    # Final Report
    # =====================================================

    report: AnalysisReport | None = None

    # =====================================================
    # Audio Processing
    # =====================================================

    processed_audio: np.ndarray | None = None

    audio_stems: list | None = None

    source_pulse_sequences: list | None = None

    # =====================================================
    # Pulse Detection
    # =====================================================

    pulse_candidates: list | None = None

    pulse_intervals: list | None = None

    # =====================================================
    # Window Analysis
    # =====================================================

    analysis_windows: list | None = None

    # =====================================================
    # Metric Stability
    # =====================================================

    stability_curve: object | None = None

    # =====================================================
    # Metric Clusters
    # =====================================================

    metric_clusters: list | None = None

    # =====================================================
    # Periodicity Discovery
    # =====================================================

    periodicity_segments: list | None = None

    # =====================================================
    # Analysis Log
    # =====================================================

    log: AnalysisLog = field(default_factory=AnalysisLog)